//
//  JKPlayerSliderView.h
//  JKPlayer
//
//  Created by Janko on 16/7/4.
//  Copyright © 2016年 Janko. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JKPlayerSliderView : UIView
@property (nonatomic, strong) UISlider *slider;
@property (nonatomic, strong) UIProgressView *progressView;
@end
