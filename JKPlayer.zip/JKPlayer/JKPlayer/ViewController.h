//
//  ViewController.h
//  JKPlayer
//
//  Created by 杨可 on 2016/12/23.
//  Copyright © 2016年 Janko. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

