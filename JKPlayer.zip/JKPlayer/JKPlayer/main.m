//
//  main.m
//  JKPlayer
//
//  Created by 杨可 on 2016/12/23.
//  Copyright © 2016年 Janko. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
